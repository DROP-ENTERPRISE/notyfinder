<?php

/**
 *
 * @package   ListingoApp Core
 * @author    themographics
 * @link      https://themeforest.net/user/themographics/portfolio
 * @since 1.0
 */
